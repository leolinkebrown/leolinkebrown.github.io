2document.addEventListener("DOMContentLoaded", function() {
    // You can add animations, interactions, or other JS code here
    console.log("Page loaded!");
});

